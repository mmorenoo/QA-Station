# QA Station - Sistema de Pruebas Automatizadas

## Descripción
Este repositorio contiene el código fuente del proyecto **QA_Station**, una plataforma para la ejecución de pruebas automatizadas de software utilizando Selenium y generación de casos de prueba con la API de OpenAI.

