from .back import BackAction
from .click import ClickAction
from .forward import ForwardAction
from .navigate_to_url import NavigateToUrlAction
from .refresh import RefreshPageAction   
from .scroll_to_element import ScrollToElementAction
from .switch_tab import SwitchTabAction