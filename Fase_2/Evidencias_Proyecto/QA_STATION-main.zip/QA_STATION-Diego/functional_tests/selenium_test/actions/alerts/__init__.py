from .accept_alert import AcceptAlertAction
from .alert_is_present import AlertIsPresentAction #GENERICA
from .confirm_alert import ConfirmAlertAction
from .dismiss_alert import DismissAlertAction
from .enter_prompt import EnterPromptAction
from .prompt_alert import PromptAlertAction
