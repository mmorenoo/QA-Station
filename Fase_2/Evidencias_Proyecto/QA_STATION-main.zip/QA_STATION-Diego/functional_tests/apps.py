from django.apps import AppConfig


class FunctionalTestsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'functional_tests'
