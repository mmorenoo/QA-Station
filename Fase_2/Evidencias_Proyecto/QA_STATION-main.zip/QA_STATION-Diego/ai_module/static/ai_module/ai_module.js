// Función para mostrar el icono de carga
function mostrarLoader() {
  document.getElementById("loading").style.display = "block";
}
